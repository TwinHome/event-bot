from django.apps import AppConfig


class ClaudeAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'claude_app'
